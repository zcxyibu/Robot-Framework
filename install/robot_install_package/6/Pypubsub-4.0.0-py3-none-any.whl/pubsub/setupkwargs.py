"""
Legacy file, no longer used (deprecated).
"""

"""
:copyright: Copyright since 2006 by Oliver Schoenborn, all rights reserved.
:license: BSD, see LICENSE_BSD_Simple.txt for details.
"""

import warnings

warnings.warn("This module is deprecated. Remove any imports of it from your code ", DeprecationWarning)
